-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2020 at 11:19 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newhotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can add permission', 2, 'add_permission'),
(5, 'Can change permission', 2, 'change_permission'),
(6, 'Can delete permission', 2, 'delete_permission'),
(7, 'Can add group', 3, 'add_group'),
(8, 'Can change group', 3, 'change_group'),
(9, 'Can delete group', 3, 'delete_group'),
(10, 'Can add user', 4, 'add_user'),
(11, 'Can change user', 4, 'change_user'),
(12, 'Can delete user', 4, 'delete_user'),
(13, 'Can add content type', 5, 'add_contenttype'),
(14, 'Can change content type', 5, 'change_contenttype'),
(15, 'Can delete content type', 5, 'delete_contenttype'),
(16, 'Can add session', 6, 'add_session'),
(17, 'Can change session', 6, 'change_session'),
(18, 'Can delete session', 6, 'delete_session'),
(19, 'Can add roomcategory', 7, 'add_roomcategory'),
(20, 'Can change roomcategory', 7, 'change_roomcategory'),
(21, 'Can delete roomcategory', 7, 'delete_roomcategory'),
(22, 'Can add roomcategorydetails', 8, 'add_roomcategorydetails'),
(23, 'Can change roomcategorydetails', 8, 'change_roomcategorydetails'),
(24, 'Can delete roomcategorydetails', 8, 'delete_roomcategorydetails'),
(25, 'Can add booking', 9, 'add_booking'),
(26, 'Can change booking', 9, 'change_booking'),
(27, 'Can delete booking', 9, 'delete_booking'),
(28, 'Can add profile', 10, 'add_profile'),
(29, 'Can change profile', 10, 'change_profile'),
(30, 'Can delete profile', 10, 'delete_profile'),
(31, 'Can add register_table', 11, 'add_register_table'),
(32, 'Can change register_table', 11, 'change_register_table'),
(33, 'Can delete register_table', 11, 'delete_register_table');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$100000$fkLcYZhFHcOU$6kOPAlUBsMJPcKL1zm7t5dD/gb1P8pj/SwCgfPeYv/E=', '2020-09-19 12:32:48.467598', 1, 'admin', '', '', 'handarajat111@gmail.com', 1, 1, '2020-08-22 14:53:16.202160'),
(9, 'pbkdf2_sha256$100000$crnFW7FFieKz$zqIippbvfFXKwT4+av6k+2yIWYt/kaMxSfD+0BAk5vI=', '2020-09-08 10:55:19.257755', 1, 'admin2', '', '', 'admin@gmail.com', 1, 1, '2020-09-08 10:54:49.509400'),
(11, 'pbkdf2_sha256$100000$fAarqjPaBetp$4eQROy6bm4SVZpVv/maVPXPmqVJtwSoOUyfhqXVEWFc=', '2020-09-14 10:01:18.189595', 0, 'Rajat12', 'Rajat', 'handa', 'handarajat111@gmail.com', 0, 0, '2020-09-10 17:22:34.225358'),
(16, 'pbkdf2_sha256$100000$PYGb4C8xKQD3$nJpZkZodgahabOF647bBQtSjo1KzmkbrO19XtWIo/Jo=', '2020-09-21 09:11:30.242570', 0, 'Rajat', 'Rajat', 'handa', 'handarajat111@gmail.com', 0, 1, '2020-09-17 14:27:06.192513'),
(17, 'pbkdf2_sha256$100000$6lIECFaPgrgZ$/lZJfsiID4cuSOb4q+mS3DuNwnjFXNfODyeFn+poHaQ=', NULL, 0, 'hello', 'dknkn', 'dlknd', 'dhjddh@gmail.com', 0, 0, '2020-09-18 11:26:20.557583'),
(18, 'pbkdf2_sha256$100000$6XFCpRTQbbWl$ve8cx5KGftKSzojT900tWZILlcNb5hL5NQMMyLtHrNo=', NULL, 0, 'nfjhfh', 'dmdmpo', 'dmdm', 'kjbgdg@gmail.com', 0, 0, '2020-09-18 11:28:08.933639');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2020-08-23 15:57:22.297582', '1', 'Presidential Suite', 1, '[{\"added\": {}}]', 7, 1),
(2, '2020-08-23 15:58:57.235505', '2', 'Premium Suite', 1, '[{\"added\": {}}]', 7, 1),
(3, '2020-08-23 15:59:07.247464', '1', 'Presidential Suite', 2, '[{\"changed\": {\"fields\": [\"roomavailable\"]}}]', 7, 1),
(4, '2020-08-23 16:00:52.086326', '3', 'Family Suite', 1, '[{\"added\": {}}]', 7, 1),
(5, '2020-08-23 16:01:30.932263', '4', 'Executive Room', 1, '[{\"added\": {}}]', 7, 1),
(6, '2020-08-23 16:02:19.967055', '5', 'Deluxe Room', 1, '[{\"added\": {}}]', 7, 1),
(7, '2020-08-23 16:02:58.357095', '6', 'Standard Room', 1, '[{\"added\": {}}]', 7, 1),
(8, '2020-08-24 05:38:46.241948', '1', 'Presidential Suite', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 7, 1),
(9, '2020-08-24 05:38:57.797817', '2', 'Premium Suite', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 7, 1),
(10, '2020-08-24 05:39:20.068676', '3', 'Family Suite', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 7, 1),
(11, '2020-08-24 05:39:31.322966', '4', 'Executive Room', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 7, 1),
(12, '2020-08-24 05:39:48.805350', '5', 'Deluxe Room', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 7, 1),
(13, '2020-08-24 05:40:02.711706', '6', 'Standard Room', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 7, 1),
(14, '2020-08-24 08:47:38.620753', '1', 'Roomcategorydetails object (1)', 1, '[{\"added\": {}}]', 8, 1),
(15, '2020-08-24 08:47:52.242570', '2', 'Roomcategorydetails object (2)', 1, '[{\"added\": {}}]', 8, 1),
(16, '2020-08-24 08:48:47.727083', '3', 'Roomcategorydetails object (3)', 1, '[{\"added\": {}}]', 8, 1),
(17, '2020-08-24 08:48:58.450566', '4', 'Roomcategorydetails object (4)', 1, '[{\"added\": {}}]', 8, 1),
(18, '2020-08-24 08:49:17.586138', '5', 'Roomcategorydetails object (5)', 1, '[{\"added\": {}}]', 8, 1),
(19, '2020-08-24 08:49:26.230635', '6', 'Roomcategorydetails object (6)', 1, '[{\"added\": {}}]', 8, 1),
(20, '2020-08-24 08:49:38.064859', '7', 'Roomcategorydetails object (7)', 1, '[{\"added\": {}}]', 8, 1),
(21, '2020-08-24 08:49:45.770635', '8', 'Roomcategorydetails object (8)', 1, '[{\"added\": {}}]', 8, 1),
(22, '2020-08-24 08:49:54.651552', '9', 'Roomcategorydetails object (9)', 1, '[{\"added\": {}}]', 8, 1),
(23, '2020-08-24 08:50:07.802598', '10', 'Roomcategorydetails object (10)', 1, '[{\"added\": {}}]', 8, 1),
(24, '2020-08-24 08:50:16.918399', '11', 'Roomcategorydetails object (11)', 1, '[{\"added\": {}}]', 8, 1),
(25, '2020-08-24 08:50:24.184995', '12', 'Roomcategorydetails object (12)', 1, '[{\"added\": {}}]', 8, 1),
(26, '2020-08-24 09:44:31.134869', '1', 'Presidential Suite', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(27, '2020-08-24 09:49:23.111930', '6', 'Standard Room', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(28, '2020-08-24 09:50:05.721835', '5', 'Deluxe Room', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(29, '2020-08-24 09:50:45.518721', '4', 'Executive Room', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(30, '2020-08-24 09:51:24.420630', '3', 'Family Suite', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(31, '2020-08-24 09:52:06.251699', '2', 'Premium Suite', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(32, '2020-08-24 09:53:19.856496', '1', 'Presidential Suite', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(33, '2020-08-24 09:53:26.359922', '1', 'Presidential Suite', 2, '[]', 7, 1),
(34, '2020-08-24 09:53:34.139040', '6', 'Standard Room', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(35, '2020-08-24 09:53:41.115659', '5', 'Deluxe Room', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(36, '2020-08-24 09:53:47.754546', '4', 'Executive Room', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(37, '2020-08-24 09:53:55.368719', '4', 'Executive Room', 2, '[]', 7, 1),
(38, '2020-08-24 09:54:02.454749', '2', 'Premium Suite', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(39, '2020-08-24 09:54:09.116859', '1', 'Presidential Suite', 2, '[]', 7, 1),
(40, '2020-08-26 10:03:41.240523', '6', 'Standard Room', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(41, '2020-08-26 10:03:48.916619', '5', 'Deluxe Room', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(42, '2020-08-26 10:03:57.613201', '4', 'Executive Room', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(43, '2020-08-26 10:04:06.185510', '3', 'Family Suite', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(44, '2020-08-26 10:04:13.184227', '2', 'Premium Suite', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(45, '2020-08-26 10:04:20.238309', '1', 'Presidential Suite', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(46, '2020-08-26 10:04:27.583053', '3', 'Family Suite', 2, '[{\"changed\": {\"fields\": [\"services\"]}}]', 7, 1),
(47, '2020-09-08 10:59:20.216249', '6', 'Profile object (6)', 2, '[{\"changed\": {\"fields\": [\"birth_date\"]}}]', 10, 9),
(48, '2020-09-10 16:59:13.310101', '6', 'Standard Room', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 7, 1),
(49, '2020-09-14 07:16:30.911875', '6', 'Standard Room', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 7, 1),
(50, '2020-09-14 15:49:26.076206', '6', 'Standard Room', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 7, 1),
(51, '2020-09-14 15:52:07.552092', '6', 'Standard Room', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session'),
(9, 'website', 'booking'),
(10, 'website', 'profile'),
(11, 'website', 'register_table'),
(7, 'website', 'roomcategory'),
(8, 'website', 'roomcategorydetails');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2020-08-22 14:52:40.900083'),
(2, 'auth', '0001_initial', '2020-08-22 14:52:42.637756'),
(3, 'admin', '0001_initial', '2020-08-22 14:52:42.991783'),
(4, 'admin', '0002_logentry_remove_auto_add', '2020-08-22 14:52:43.004780'),
(5, 'contenttypes', '0002_remove_content_type_name', '2020-08-22 14:52:43.148793'),
(6, 'auth', '0002_alter_permission_name_max_length', '2020-08-22 14:52:43.351807'),
(7, 'auth', '0003_alter_user_email_max_length', '2020-08-22 14:52:43.398811'),
(8, 'auth', '0004_alter_user_username_opts', '2020-08-22 14:52:43.415812'),
(9, 'auth', '0005_alter_user_last_login_null', '2020-08-22 14:52:43.549822'),
(10, 'auth', '0006_require_contenttypes_0002', '2020-08-22 14:52:43.559821'),
(11, 'auth', '0007_alter_validators_add_error_messages', '2020-08-22 14:52:43.590828'),
(12, 'auth', '0008_alter_user_username_max_length', '2020-08-22 14:52:43.801839'),
(13, 'auth', '0009_alter_user_last_name_max_length', '2020-08-22 14:52:43.840841'),
(14, 'sessions', '0001_initial', '2020-08-22 14:52:43.978859'),
(15, 'website', '0001_initial', '2020-08-23 15:48:34.465024'),
(16, 'website', '0002_roomcategorydetails', '2020-08-24 08:46:04.301245'),
(17, 'website', '0003_booking', '2020-08-25 11:27:58.675089'),
(18, 'website', '0004_profile', '2020-08-30 11:07:46.140420'),
(19, 'website', '0005_profile_profile_image', '2020-09-14 10:09:17.735542'),
(20, 'website', '0006_remove_profile_profile_image', '2020-09-14 10:24:59.890777'),
(21, 'website', '0007_auto_20200914_2120', '2020-09-14 15:50:42.556542'),
(22, 'website', '0008_register_table', '2020-09-17 10:22:23.061344');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('1mm59mxzhfc873t19lq7jgbbf2cw25b7', 'ZjNjYjIyNjY2ZDMzODI0ODdjMGYzNjUzYjgzYjljZDcxNTY0OGNiNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyZDg0MjU3Yzg4ZjFiZmZkOTVkMGQxODM5YWRlYTAxMzE0MWYyY2FhIn0=', '2020-09-28 15:48:45.618804'),
('1u4s7i9r20kbf3wttx3t5ucvii6u9pjv', 'ZmRhYzhhNWI5MzRmNTQ2MDFhMGI0MDAwZjNlYTNkNzBjMjZiNzEyZTp7ImNhdGlkIjoyLCJfYXV0aF91c2VyX2lkIjoiMTEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjkzNDJiMmI5ZDM3NDJmMTZhZDQ4MWNhYjc1YTVhYTlmMzE0ZjZhZTEiLCJ1c2VyaWQiOjExLCJteXVzZXJuYW1lIjoiUmFqYXQiLCJteXVzZXJlbWFpbCI6ImhhbmRhcmFqYXQxMTFAZ21haWwuY29tIn0=', '2020-09-24 17:28:01.264981'),
('2stehua2gidv4iivy4sia59a65oywxkm', 'YzkyYjczZTY3MDc0M2QxODBiNDJkMzUyMTU0YmVhZmQ0OWZiNmI5ZTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMTk1NDVjNGNkMzUxMjNhMDJmOGNjOWM1MzFhY2M1MmU3OWFjNzk1IiwidXNlcmlkIjoyLCJteXVzZXJuYW1lIjoiUmFqYXQiLCJteXVzZXJlbWFpbCI6ImhlbGxvQGdtYWlsLmNvbSIsImNhdGlkIjoyfQ==', '2020-09-08 16:43:59.436353'),
('3dr670d3fdzbodk6r5t9alyxh5ek3pef', 'YzkyYjczZTY3MDc0M2QxODBiNDJkMzUyMTU0YmVhZmQ0OWZiNmI5ZTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMTk1NDVjNGNkMzUxMjNhMDJmOGNjOWM1MzFhY2M1MmU3OWFjNzk1IiwidXNlcmlkIjoyLCJteXVzZXJuYW1lIjoiUmFqYXQiLCJteXVzZXJlbWFpbCI6ImhlbGxvQGdtYWlsLmNvbSIsImNhdGlkIjoyfQ==', '2020-09-09 16:56:08.303156'),
('5tmwfwhcpl2wmw8jvyvtrk4dhy92v208', 'ODBiYzcwOTBiYmJkNDA5NDY5MDMyOWZjNWU4OGM1N2JjOTMzYzk0Mjp7Il9hdXRoX3VzZXJfaWQiOiIxMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiOTM0MmIyYjlkMzc0MmYxNmFkNDgxY2FiNzVhNWFhOWYzMTRmNmFlMSJ9', '2020-09-24 17:22:47.912760'),
('6bpe7zig0fi9j8h87lah2t9y7e7zmgvc', 'MzIwNGI5ODg1Mjg2M2FlOTE4Y2U0YTg4NzMzZjI1MjcyZmVmYmYzNTp7Il9hdXRoX3VzZXJfaWQiOiI2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhNjhmMTc4YzQ1ZmNiODM5NWViOTdiZTIwMWM3OTk1NGFhZWY0YmNlIiwidXNlcmlkIjo2LCJteXVzZXJuYW1lIjoiUmFqYXRIYW5kYSIsIm15dXNlcmVtYWlsIjoiUmFqYXRoYW5kYUBnbWFpbC5jb20iLCJjYXRpZCI6Mn0=', '2020-09-15 08:41:28.276496'),
('6praez1j8qt2zjhavw2sx5uhjcoerwym', 'ZDg4OTEzNmJmMjY1MmY4OGJkNTE3ODQ2NWU3ZTExYmNlMTcxMmJlMDp7ImNhdGlkIjoyLCJfYXV0aF91c2VyX2lkIjoiMTYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImE0MTY4YTIzMWJhMDA4MTRiMTk2NGQ1MjZiMjU1YjJjNzNlODg3MGYiLCJ1c2VyaWQiOjE2LCJteXVzZXJuYW1lIjoiUmFqYXQiLCJteXVzZXJlbWFpbCI6ImhhbmRhcmFqYXQxMTFAZ21haWwuY29tIn0=', '2020-10-05 09:11:30.250571'),
('8n7hu7oc7oak8gdxihkfnie3g7vag7in', 'ODkxODkzNTNhMGNkMjkwNTEwYjliZmI3ZTFhMDRhNTIxZWM2MTMwODp7fQ==', '2020-09-13 11:08:40.612508'),
('9rozbojr0n4bckk5t8hwguzakevbzliy', 'NzAxNDY0MWYzMDYwNzNkMDFjNmJmNTIzYzQxZGM5ZjgyYWU0NTEwNDp7Il9hdXRoX3VzZXJfaWQiOiI4IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzZDhiMTYxNTI1MjhlZmJlYjYxYzAyZGI0YTQ3MDc1NTBhNzQyMWNmIn0=', '2020-09-20 08:37:32.994951'),
('eikux50su7cm1bb7psa5apcvqtumrmzv', 'ZDMzMjYwMGQ3MTMxYTY2Yzk1MDQ2MjIzZDM3ZTg5ZTQ4MGNlMzMyMjp7ImNhdGlkIjo2fQ==', '2020-09-09 10:09:41.757410'),
('eymnk08lpoffsnsweeb9t4opxwpr5dvz', 'N2ZhYTkwM2QzNjU2ZjRlY2JhODdiZGJmZDUzYTkyNmY5MmQ2NjE3MTp7Il9hdXRoX3VzZXJfaWQiOiI5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiMjI4MmUyNzAwOWNhYjdlYzQxYWNmNmM2NWE0ZTYxMTVkODg5NWQ0In0=', '2020-09-22 10:55:19.266755'),
('i5x4zyebjyzqsku8qdgqcrh8v1wey3zy', 'ZTYwYTg4NmZiMTNiN2UwOGUyMjY1ODBmOWUxOThhN2Y0OWFjZjg0Yjp7ImNhdGlkIjoyLCJfYXV0aF91c2VyX2lkIjoiMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMmQ4NDI1N2M4OGYxYmZmZDk1ZDBkMTgzOWFkZWEwMTMxNDFmMmNhYSJ9', '2020-09-24 16:58:24.281939'),
('j61ge92ette7t08eiujbdgq92qgg1cyr', 'NGQyMTY3NGI4MTUzOTUwMjVmYTZmMmE4ZjZkYzc5NzNlNzQzMWQwYjp7ImNhdGlkIjoyLCJfYXV0aF91c2VyX2lkIjoiNiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYTY4ZjE3OGM0NWZjYjgzOTVlYjk3YmUyMDFjNzk5NTRhYWVmNGJjZSIsInVzZXJpZCI6NiwibXl1c2VybmFtZSI6IlJhamF0SGFuZGEiLCJteXVzZXJlbWFpbCI6IlJhamF0aGFuZGFAZ21haWwuY29tIn0=', '2020-09-17 17:06:56.670997'),
('lt3ou2u06oaccka2g219e4ppbhzv9w2d', 'YzkyYjczZTY3MDc0M2QxODBiNDJkMzUyMTU0YmVhZmQ0OWZiNmI5ZTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMTk1NDVjNGNkMzUxMjNhMDJmOGNjOWM1MzFhY2M1MmU3OWFjNzk1IiwidXNlcmlkIjoyLCJteXVzZXJuYW1lIjoiUmFqYXQiLCJteXVzZXJlbWFpbCI6ImhlbGxvQGdtYWlsLmNvbSIsImNhdGlkIjoyfQ==', '2020-09-09 09:46:47.279527'),
('lyr1ri5z1m7k30nn93ijmreosxodd9sp', 'MDRiZjA5MDAwYTNiNjY5MTc0NjA3ZWQ1YWU4MTBhMDY1ZjMwZWE0NTp7ImNhdGlkIjo0LCJfYXV0aF91c2VyX2lkIjoiMTQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjMxNzQ4YjYwZWZiMjAyNWEzZjUyZGJhZjZmNzk2YWUwM2JkZmE0MjMiLCJ1c2VyaWQiOjE0LCJteXVzZXJuYW1lIjoiUmFqYXQiLCJteXVzZXJlbWFpbCI6ImhhbmRhcmFqYXQxMTFAZ21haWwuY29tIn0=', '2020-10-01 10:19:42.561466'),
('nluuqhhqzq5qfjazd94oo4axzob91qxi', 'YzUyYTMxNDgzZjcwOTBjODE0MjA3M2E2YWQzNGJiN2NlOTRiMmRjMjp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1NzRkYjBlNjc4NWY3MzNmOTAzNjdjZjQ2ZGE3OWE1NmQ3ZjZhMjBiIiwidXNlcmlkIjoyLCJteXVzZXJuYW1lIjoiUmFqYXQiLCJteXVzZXJlbWFpbCI6ImhlbGxvQGdtYWlsLmNvbSJ9', '2020-09-08 09:55:10.780315'),
('nro2zxni9vxp7a9t79l64dz48y1k3hgg', 'ZjNjYjIyNjY2ZDMzODI0ODdjMGYzNjUzYjgzYjljZDcxNTY0OGNiNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyZDg0MjU3Yzg4ZjFiZmZkOTVkMGQxODM5YWRlYTAxMzE0MWYyY2FhIn0=', '2020-10-03 08:30:29.449788'),
('oxilt43neb7jgjuivzhidw3lry4v9ud0', 'OTYxMGM5N2Y2NGI2MGY2MWMxNjdkODZlNmM0YTFjNmZkYTc4OWZiMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyZDg0MjU3Yzg4ZjFiZmZkOTVkMGQxODM5YWRlYTAxMzE0MWYyY2FhIiwiY2F0aWQiOjF9', '2020-09-07 10:26:12.476061'),
('p6w9i1q625qowjz43hb0tlrr6u8l2hrl', 'OTJhNGM0NGY4NjVhNThhMDkzNTRlMDM4ZmQ4MGM2MzMyNmFiZjFiZjp7Il9hdXRoX3VzZXJfaWQiOiIxNiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYTQxNjhhMjMxYmEwMDgxNGIxOTY0ZDUyNmIyNTViMmM3M2U4ODcwZiIsInVzZXJpZCI6MTYsIm15dXNlcm5hbWUiOiJSYWphdCIsIm15dXNlcmVtYWlsIjoiaGFuZGFyYWphdDExMUBnbWFpbC5jb20ifQ==', '2020-10-01 15:16:31.411829'),
('rre4tpaashuyiotren547gfw5q0amaoi', 'ZjNjYjIyNjY2ZDMzODI0ODdjMGYzNjUzYjgzYjljZDcxNTY0OGNiNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyZDg0MjU3Yzg4ZjFiZmZkOTVkMGQxODM5YWRlYTAxMzE0MWYyY2FhIn0=', '2020-09-28 07:16:12.210129'),
('tuiziynlc3i1lyopjjv7zh7m9i086p9x', 'ZjNjYjIyNjY2ZDMzODI0ODdjMGYzNjUzYjgzYjljZDcxNTY0OGNiNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyZDg0MjU3Yzg4ZjFiZmZkOTVkMGQxODM5YWRlYTAxMzE0MWYyY2FhIn0=', '2020-09-05 14:55:23.092707'),
('u2q7sfdtfw5uqc1it1blqjse3zcbrgs0', 'MGNlYmRhMTMwNmI5Y2Y1NDMzYzM1MmFhYWM5ZGQzNDI4NjA1YTI4OTp7ImNhdGlkIjoyfQ==', '2020-09-08 09:54:13.569716'),
('wjvxc8zk18xzenut2fyacwem098qnf1b', 'YTc0ZWZmMDFjMjcxOWVlNjI0ZTRjMGVlY2MwNjAwZDM5MGRhZTE5Mzp7Il9hdXRoX3VzZXJfaWQiOiIxMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiOTM0MmIyYjlkMzc0MmYxNmFkNDgxY2FiNzVhNWFhOWYzMTRmNmFlMSIsInVzZXJpZCI6MTEsIm15dXNlcm5hbWUiOiJSYWphdCIsIm15dXNlcmVtYWlsIjoiaGFuZGFyYWphdDExMUBnbWFpbC5jb20ifQ==', '2020-09-28 10:01:18.197405'),
('y44qcvwyqdqel7mdzes6nyv4sl9tn3k1', 'NmIyOTQ1YzlhYjk0MWVhZDU5OGMxNzg1ZGNhOWZhZjQ2ZDljZDRhMjp7Il9hdXRoX3VzZXJfaWQiOiI2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhNjhmMTc4YzQ1ZmNiODM5NWViOTdiZTIwMWM3OTk1NGFhZWY0YmNlIiwidXNlcmlkIjo2LCJteXVzZXJuYW1lIjoiUmFqYXRIYW5kYSIsIm15dXNlcmVtYWlsIjoiUmFqYXRoYW5kYUBnbWFpbC5jb20iLCJjYXRpZCI6Nn0=', '2020-09-15 10:30:47.682744'),
('y4q5cevfjjp1hvggzf3zsdxq5fdclwhz', 'NjkxYmQzOTVhZTY3NTk2YjU3NGEwODYzNjNmMTcyOGMwZThlNjZjNDp7ImNhdGlkIjoyLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYTE5NTQ1YzRjZDM1MTIzYTAyZjhjYzljNTMxYWNjNTJlNzlhYzc5NSIsInVzZXJpZCI6MiwibXl1c2VybmFtZSI6IlJhamF0IiwibXl1c2VyZW1haWwiOiJoZWxsb0BnbWFpbC5jb20ifQ==', '2020-09-12 12:31:22.719524'),
('yn345ceolveyiyurjzcb1nc8f7iswmur', 'ZjNjYjIyNjY2ZDMzODI0ODdjMGYzNjUzYjgzYjljZDcxNTY0OGNiNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyZDg0MjU3Yzg4ZjFiZmZkOTVkMGQxODM5YWRlYTAxMzE0MWYyY2FhIn0=', '2020-10-03 12:32:48.485125'),
('yoigbsrp6ega1g8qqtnzbtk7x22z92x8', 'MTczZGUyYzkyMGQ5M2YzNDg4Y2I5YTljMTM1NGRlMTMzY2QyZWQyOTp7Il9hdXRoX3VzZXJfaWQiOiIxNiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYTQxNjhhMjMxYmEwMDgxNGIxOTY0ZDUyNmIyNTViMmM3M2U4ODcwZiIsInVzZXJpZCI6MTYsIm15dXNlcm5hbWUiOiJSYWphdCIsIm15dXNlcmVtYWlsIjoiaGFuZGFyYWphdDExMUBnbWFpbC5jb20iLCJjYXRpZCI6Mn0=', '2020-10-02 10:44:26.445340'),
('zo33cr6qkw2i387c0awzbi979v73ucyr', 'ZjNjYjIyNjY2ZDMzODI0ODdjMGYzNjUzYjgzYjljZDcxNTY0OGNiNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyZDg0MjU3Yzg4ZjFiZmZkOTVkMGQxODM5YWRlYTAxMzE0MWYyY2FhIn0=', '2020-09-09 10:02:30.642943'),
('ztjz3wing5evdd4ql6loqx9198nf1aer', 'N2EwNzg1MTk1ZmM2NmZlYzU4ZGVhYjZmN2M1ZTNjMzU1MzkwYmFjYTp7Il9hdXRoX3VzZXJfaWQiOiIxNiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYTQxNjhhMjMxYmEwMDgxNGIxOTY0ZDUyNmIyNTViMmM3M2U4ODcwZiJ9', '2020-10-01 14:27:21.690680');

-- --------------------------------------------------------

--
-- Table structure for table `website_booking`
--

CREATE TABLE `website_booking` (
  `id` int(11) NOT NULL,
  `checkindate` date NOT NULL,
  `checkoutdate` date NOT NULL,
  `amount` int(11) NOT NULL,
  `totalpersons` int(11) NOT NULL,
  `guestname` varchar(70) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `roomcategoryid_id` int(11) NOT NULL,
  `roomdetailid_id` int(11) NOT NULL,
  `userid_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `website_booking`
--

INSERT INTO `website_booking` (`id`, `checkindate`, `checkoutdate`, `amount`, `totalpersons`, `guestname`, `gender`, `roomcategoryid_id`, `roomdetailid_id`, `userid_id`) VALUES
(19290, '2020-09-15', '2020-09-17', 700, 3, 'AjayHanda', 'male', 6, 1, 11),
(19291, '2020-09-23', '2020-09-25', 5000, 2, 'Rishabh', 'male', 2, 9, 16),
(19292, '2020-09-24', '2020-09-29', 7800, 3, 'Rajat', 'male', 1, 11, 16),
(19293, '2020-09-24', '2020-09-29', 7800, 3, 'Rajat', 'male', 1, 11, 16),
(19294, '2020-09-24', '2020-09-29', 7800, 3, 'Rajat', 'male', 1, 11, 16),
(19295, '2020-09-23', '2020-09-29', 9600, 2, 'Rajat', 'male', 1, 12, 16);

-- --------------------------------------------------------

--
-- Table structure for table `website_profile`
--

CREATE TABLE `website_profile` (
  `id` int(11) NOT NULL,
  `birth_date` date DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `website_profile`
--

INSERT INTO `website_profile` (`id`, `birth_date`, `phone`, `user_id`) VALUES
(5, NULL, NULL, 1),
(13, NULL, NULL, 16),
(14, NULL, NULL, 17),
(15, NULL, NULL, 18);

-- --------------------------------------------------------

--
-- Table structure for table `website_register_table`
--

CREATE TABLE `website_register_table` (
  `id` int(11) NOT NULL,
  `profile_pic` varchar(100) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `website_register_table`
--

INSERT INTO `website_register_table` (`id`, `profile_pic`, `user_id`) VALUES
(2, 'profiles/2020/09/19/crop_0sp2lPG.jpeg', 16),
(3, '/staticfiles/images/user.png', 17),
(4, '/staticfiles/images/user.png', 18);

-- --------------------------------------------------------

--
-- Table structure for table `website_roomcategory`
--

CREATE TABLE `website_roomcategory` (
  `id` int(11) NOT NULL,
  `categoryname` varchar(30) NOT NULL,
  `services` longtext NOT NULL,
  `roomsize` varchar(30) NOT NULL,
  `beds` varchar(30) NOT NULL,
  `capcity` varchar(30) NOT NULL,
  `bedtype` varchar(30) NOT NULL,
  `roomavailable` int(11) NOT NULL,
  `Image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `website_roomcategory`
--

INSERT INTO `website_roomcategory` (`id`, `categoryname`, `services`, `roomsize`, `beds`, `capcity`, `bedtype`, `roomavailable`, `Image`) VALUES
(1, 'Presidential Suite', '<h2><u><strong>SERVICES :</strong></u></h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Television</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Air Conditioner</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔WIFI</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Refrigretor</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Washroom</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ✔Jacuzzi Facility</p>', '80x10 Feet', '2-3 Beds', 'Max 5-6 Person', '3 King Size Bed', 5, 'pics/Joaquim-Suite-Living-Room.jpg'),
(2, 'Premium Suite', '<h2><u><strong>SERVICES:</strong></u></h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Television</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Air Conditioner</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔WIFI</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Refrigretor</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Washroom</p>\r\n\r\n<p>&nbsp;</p>', '70x10 Feet', '2-3 Beds', 'Max 5-6 Person', '2 King Size Bed', 7, 'pics/Presidential-Suite3.jpg'),
(3, 'Family Suite', '<h2><u><strong>SERVICES:</strong></u></h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Television</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Air Conditioner</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔WIFI</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Refrigretor</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Washroom</p>\r\n\r\n<p>&nbsp;</p>', '60x10 Feet', '2 Beds', 'Max 4 Person', '2 King Size Bed', 10, 'pics/family-suit.jpg'),
(4, 'Executive Room', '<h2><u><strong>SERVICES:</strong></u></h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ✔Television</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ✔Air Conditioner</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ✔WIFI</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ✔Washroom</p>\r\n\r\n<p>&nbsp;</p>', '50x10 Feet', '2 Beds', 'Max 3 Person', 'King Size Bed', 15, 'pics/execu.jpg'),
(5, 'Deluxe Room', '<h2><u><strong>SERVICES:</strong></u></h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Television</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Air Conditioner</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ✔WIFI</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ✔Washroom</p>\r\n\r\n<p>&nbsp;</p>', '40x10 Feet', '1 Bed', '1 Person Only', 'King Size Bed', 20, 'pics/delux.jpg'),
(6, 'Standard Room', '<h2><u><strong>SERVICES:</strong></u></h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Television</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Air Conditioner&nbsp;</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;✔Washroom</p>\r\n\r\n<p>&nbsp;</p>', '30x10 Feet', '1 Bed', '1 Person Only', 'Queen Size Bed', 25, 'uploads/2020/09/14/standrd.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `website_roomcategorydetails`
--

CREATE TABLE `website_roomcategorydetails` (
  `id` int(11) NOT NULL,
  `roomoption` varchar(200) NOT NULL,
  `roomprice` int(11) NOT NULL,
  `roomcategoryid_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `website_roomcategorydetails`
--

INSERT INTO `website_roomcategorydetails` (`id`, `roomoption`, `roomprice`, `roomcategoryid_id`) VALUES
(1, 'Rooms with breakfast', 700, 6),
(2, 'Rooms with breakfast , lunch and dinner', 1200, 6),
(3, 'Rooms with breakfast', 1500, 5),
(4, 'Rooms with breakfast , lunch and dinner', 2000, 5),
(5, 'Rooms with breakfast', 2200, 4),
(6, 'Rooms with breakfast , lunch and dinner', 2800, 4),
(7, 'Rooms with breakfast', 3000, 3),
(8, 'Rooms with breakfast , lunch and dinner', 4000, 3),
(9, 'Rooms with breakfast', 5000, 2),
(10, 'Rooms with breakfast , lunch and dinner', 6500, 2),
(11, 'Rooms with breakfast', 7800, 1),
(12, 'Rooms with breakfast , lunch and dinner', 9600, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `website_booking`
--
ALTER TABLE `website_booking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `website_booking_roomcategoryid_id_b6689a76_fk_website_r` (`roomcategoryid_id`),
  ADD KEY `website_booking_roomdetailid_id_f7719162_fk_website_r` (`roomdetailid_id`),
  ADD KEY `website_booking_userid_id_f27b70f7_fk_auth_user_id` (`userid_id`);

--
-- Indexes for table `website_profile`
--
ALTER TABLE `website_profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `website_register_table`
--
ALTER TABLE `website_register_table`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `website_roomcategory`
--
ALTER TABLE `website_roomcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `website_roomcategorydetails`
--
ALTER TABLE `website_roomcategorydetails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `website_roomcategory_roomcategoryid_id_04fade59_fk_website_r` (`roomcategoryid_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `website_booking`
--
ALTER TABLE `website_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19296;

--
-- AUTO_INCREMENT for table `website_profile`
--
ALTER TABLE `website_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `website_register_table`
--
ALTER TABLE `website_register_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `website_roomcategory`
--
ALTER TABLE `website_roomcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `website_roomcategorydetails`
--
ALTER TABLE `website_roomcategorydetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `website_booking`
--
ALTER TABLE `website_booking`
  ADD CONSTRAINT `website_booking_roomcategoryid_id_b6689a76_fk_website_r` FOREIGN KEY (`roomcategoryid_id`) REFERENCES `website_roomcategory` (`id`),
  ADD CONSTRAINT `website_booking_roomdetailid_id_f7719162_fk_website_r` FOREIGN KEY (`roomdetailid_id`) REFERENCES `website_roomcategorydetails` (`id`),
  ADD CONSTRAINT `website_booking_userid_id_f27b70f7_fk_auth_user_id` FOREIGN KEY (`userid_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `website_profile`
--
ALTER TABLE `website_profile`
  ADD CONSTRAINT `website_profile_user_id_87886a5c_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `website_register_table`
--
ALTER TABLE `website_register_table`
  ADD CONSTRAINT `website_register_table_user_id_75e9e8c6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `website_roomcategorydetails`
--
ALTER TABLE `website_roomcategorydetails`
  ADD CONSTRAINT `website_roomcategory_roomcategoryid_id_04fade59_fk_website_r` FOREIGN KEY (`roomcategoryid_id`) REFERENCES `website_roomcategory` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
